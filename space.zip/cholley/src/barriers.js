import * as THREE from 'three'
function barriers(barrier,scene,level) {

    /*var textureLoader = new THREE.TextureLoader();
var wallTexture = textureLoader.load('.././assets/models/Grass001_1K-PNG/Grass001_1K_Color.png');
var wallNormalMap = textureLoader.load('.././assets/models/Grass001_1K-PNG/Grass001_1K_NormalDX.png');
var wallDisplayMap = textureLoader.load('.././assets/models/Grass001_1K-PNG/Grass001_1K_Displacement.png');
var wallRoughnessMap = textureLoader.load('.././assets/models/Grass001_1K-PNG/Grass001_1K_Roughness.png');

// Créer le matériau du mur en utilisant les deux textures
var wallMaterial = new THREE.MeshPhongMaterial({
  map: wallTexture,
  displacementMap: wallDisplayMap,
  displacementScale: 0.1,
  normalMap: wallNormalMap,
  roughnessMap: wallRoughnessMap

});*/



const barrierGeometry = new THREE.BoxGeometry(2.25, 1.5, 0.75);
const barrierGeometry2 = new THREE.BoxGeometry(0.3214 , 0.3214 , 0.75);

const barrierMaterial = new THREE.MeshPhongMaterial({
  color: 0x3e2723,
  shininess: 100,
  specular: 0x888888,
  emissive: 0x333333,
  emissiveIntensity: 0.2
});


/*
for (let i = 0; i < 4; i++) {
  const barrierBlock = new THREE.Mesh(barrierGeometry, barrierMaterial);
  barrierBlock.position.x = -10+i*6.8;
  barrierBlock.position.y = 0.5; // ajuster la position verticale ici
  barrierBlock.position.z = 25;
  barrier.push(barrierBlock);
  scene.add(barrierBlock);
}*/

//0.3214 
console.log("le niveauuu"+level); 

let pos = -10;
let nb_barriers;
if (level==1) nb_barriers=4;
if (level==2) {
  nb_barriers=2;
  pos = (Math.random() * 4) - 10;
}
if (level==3){
  nb_barriers=1;
  pos = (Math.random() * 14) - 10;
 }
//else nb_barriers=1;


const GroupC= new THREE.Group();
for (let k = 0;k<nb_barriers;k++){
for (let i = 0; i < 7; i++) {
  for (let j = 0; j < 5; j++) {
    const barrierBlock = new THREE.Mesh(barrierGeometry2, barrierMaterial);
    barrierBlock.position.x = pos+k*6+0.3214*i;
    barrierBlock.position.y = 0.3214*j; // ajuster la position verticale ici
    barrierBlock.position.z = 25;
   GroupC.add(barrierBlock);
   barrier.push(barrierBlock);
   scene.add(barrierBlock);
  }
}

}
    return barrier;
}

export {barriers}