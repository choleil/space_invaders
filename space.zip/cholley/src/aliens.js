import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader';

import { animation_base2 } from './animations'
import { animation_base3 } from './animations'
import { animation_base4 } from './animations'

import { clone } from 'three/examples/jsm/utils/SkeletonUtils.js';
import { scaleModel } from './scale'
const PI =Math.PI;

let chicken2=[];

const dracoLoader = new DRACOLoader();
dracoLoader.setDecoderPath( 'node_modules/three/examples/js/libs/draco/');// Spécifier le chemin vers le décodeur Draco

// Créer un chargeur GLTFLoader et lui ajouter le DracoLoader
const gltfLoader = new GLTFLoader();
gltfLoader.setDRACOLoader(dracoLoader);

/*
async function alien1(chicken,scene) {

    gltfLoader.load( 'http://localhost:5173/assets/models/lowpoly_duck_animated/output_model.glb', function ( gltf ) {
        const model = gltf.scene;
      
       let  x = -9;
        for (let i = 0;i <25;i++){
           
            let chicken_model = clone(model);
            let name = "chicken"+i.toString();
            chicken_model.name=name;
            if (i<12){
                chicken_model.position.set(x,0,-3);
                x+=1.65;
            }
            if (i==12){
                x = -9;
                chicken_model.position.set(x,0,-6);
            }
            else if (i>12){
                chicken_model.position.set(x,0,-6);
                x+=1.65;
            }
            chicken.push([chicken_model.name,true,0,chicken_model,gltf.animations]);
            chicken2.push([chicken_model.name,true,0,chicken_model,gltf.animations]);

             scaleModel(chicken[i][3], chicken[i][3].scale.x*2.5);
      
             chicken_model.rotation.y=PI;
             //chicken_model.rotation.y=PI;
            scene.add(chicken[i][3]);
            animation_base2(chicken);
            
        }
      
      }, undefined, function ( error ) {
        console.error( error );
      });


    return chicken;
}*/


async function alien1(chicken, scene) {

  gltfLoader.load('http://localhost:5173/assets/models/lowpoly_duck_animated/output_model.glb', function(gltf) {
    const model = gltf.scene;

    const outerCircleRadius = 12; // rayon du cercle extérieur
    const innerCircleRadius = 9; // rayon du cercle intérieur
    const numChickens = 25;
    const angleBetweenChickens = 2 * Math.PI / numChickens;

    for (let i = 0; i < numChickens; i++) {
      const chicken_model = clone(model);
      const name = "chicken" + i.toString();
      chicken_model.name = name;

      // Calculer la position du poulet sur le cercle extérieur
      const outerCircleX = outerCircleRadius * Math.cos(i * angleBetweenChickens);
      const outerCircleZ = outerCircleRadius * Math.sin(i * angleBetweenChickens);

      // Calculer la position du poulet sur le cercle intérieur
      const innerCircleX = innerCircleRadius * Math.cos(i * angleBetweenChickens);
      const innerCircleZ = innerCircleRadius * Math.sin(i * angleBetweenChickens);

      // Placer le poulet sur le cercle extérieur pour les indices pairs, et sur le cercle intérieur pour les indices impairs
      if (i % 2 === 0) {
        chicken_model.position.set(outerCircleX, 0, outerCircleZ);
      } else {
        chicken_model.position.set(innerCircleX, 0, innerCircleZ);
      }

      chicken.push([chicken_model.name, true, 0, chicken_model, gltf.animations]);
      chicken2.push([chicken_model.name, true, 0, chicken_model, gltf.animations]);

      scaleModel(chicken[i][3], chicken[i][3].scale.x * 2.5);

      chicken_model.rotation.y = PI;
      scene.add(chicken[i][3]);
      animation_base2(chicken);
    }

  }, undefined, function(error) {
    console.error(error);
  });

  return chicken;
}





/*
async function alien2(duck,scene) {

gltfLoader.load( 'http://localhost:5173/assets/models/low_poly_bird_animated/output_model.glb', function ( gltf ) {
const model = gltf.scene;

let  x = -9;
x= -9;
for (let i = 0;i <25;i++){

let duck_model = clone(model);
let name = "duck"+i.toString();
duck_model.name=name;
if (i<12){
    duck_model.position.set(x,0.5,-9);
    x+=1.65;
}
if (i==12){
    x = -9;
    duck_model.position.set(x,0.5,-12);
}
else if (i>12){
    duck_model.position.set(x,0.5,-12);
    x+=1.65;
}
duck.push([duck_model.name,true,0,duck_model,gltf.animations]);

scaleModel(duck[i][3], duck[i][3].scale.x*0.25);
scene.add(duck[i][3]);

animation_base3(duck);

}


}, undefined, function ( error ) {
console.error( error );
});
return duck;
}*/

async function alien2(duck, scene) {

    gltfLoader.load('http://localhost:5173/assets/models/low_poly_bird_animated/output_model.glb', function(gltf) {
        const model = gltf.scene;

        let x = -9;
        let z = -6;
        let angle = 0;
        let angleStep = (2 * Math.PI) / 12;

        // Premier cercle de canards
        for (let i = 0; i < 12; i++) {
            let duck_model = clone(model);
            let name = "duck" + i.toString();
            duck_model.name = name;

            let posX = x + Math.cos(angle) * 4;
            let posZ = z + Math.sin(angle) * 4;
            duck_model.position.set(posX, 0.5, posZ);

            duck.push([duck_model.name, true, 0, duck_model, gltf.animations]);

            scaleModel(duck[i][3], duck[i][3].scale.x * 0.25);
            scene.add(duck[i][3]);

            animation_base3(duck);
            angle += angleStep;
        }

        x = -9;
        z = -6;
        angle = 0;
        angleStep = (2 * Math.PI) / 12;

        // Deuxième cercle de canards
        for (let i = 12; i < 24; i++) {
            let duck_model = clone(model);
            let name = "duck" + i.toString();
            duck_model.name = name;

            let posX = x + Math.cos(angle) * 2;
            let posZ = z + Math.sin(angle) * 2;
            duck_model.position.set(posX, 0.5, posZ);

            duck.push([duck_model.name, true, 0, duck_model, gltf.animations]);

            scaleModel(duck[i][3], duck[i][3].scale.x * 0.25);
            scene.add(duck[i][3]);

            animation_base3(duck);
            angle += angleStep;
        }

    }, undefined, function(error) {
        console.error(error);
    });

    return duck;
}




async function alien3(owl,scene) {

    gltfLoader.load( 'http://localhost:5173/assets/models/lowpoly_animated_turkey/output_model.glb', function ( gltf ) {
const model = gltf.scene;

let  x = -9;
for (let i = 0;i <12;i++){

let owl_model = clone(model);
let name = "owl"+i.toString();
owl_model.name=name;

    owl_model.position.set(x,1,-15);
    x+=1.65;


owl.push([owl_model.name,true,0,owl_model,gltf.animations]);
scaleModel(owl[i][3], owl[i][3].scale.x*0.15);


// owl_model.rotation.y=7*PI/6;
scene.add(owl[i][3]);
animation_base4(owl);

}


}, undefined, function ( error ) {
console.error( error );
});
return owl;

}


export {alien1,alien2,alien3}
