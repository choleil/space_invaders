function scaleModel(model, sizeMax){
    model.scale.x = sizeMax;
    model.scale.y =  sizeMax;
    model.scale.z =  sizeMax;
  }

  export {scaleModel}