import * as THREE from 'three'

function animation_base(Alien_1_Data,Alien_1_Model,mixer){

    const clip = Alien_1_Data.animations[0];
    //console.log(clip);
    mixer = new THREE.AnimationMixer(Alien_1_Model);
    let action = mixer.clipAction(clip);
    action.play();
    //action.paused = !loopOn;
    return mixer;
  
  }
  
  
  
  function animation_base2(chicken){
    for(let i=0;i<chicken.length;i++){
      if (chicken[i][1]){
        let animation = chicken[i][4];
        let clip = animation[0];
        chicken[i][2]=new THREE.AnimationMixer(chicken[i][3]);
        let action = chicken[i][2].clipAction(clip);
        action.play();
        
       // action.paused =!loopOn;
      }
  
  }
  }
  
  function animation_base3(duck){
    for(let i=0;i<duck.length;i++){
      if (duck[i][1]){
        let animation = duck[i][4];
    
        let clip = animation[0];
        duck[i][2]=new THREE.AnimationMixer(duck[i][3]);
        let action = duck[i][2].clipAction(clip);
        action.play();
        action.setEffectiveTimeScale(2);
       // action.paused =!loopOn;
      }
  
  }
  }
  
  function animation_base4(owl){
    for(let i=0;i<owl.length;i++){
      if (owl[i][1]){
        let animation = owl[i][4];
        let clip = animation[7];
        owl[i][2]=new THREE.AnimationMixer(owl[i][3]);
        let action = owl[i][2].clipAction(clip);
        action.play();
      //  action.paused =!loopOn;
      }
  
  }
  }
  
  function animation_projectil_alien(projectil_alien2,valeur_i){
    //console.log(projectil_alien2);
        let animation = projectil_alien2[valeur_i][2];
        let clip = animation[0];
  //console.log(projectil_alien2[valeur_i][0]);
  //console.log("cest le typppeee"+type);
        projectil_alien2[valeur_i][1]=new THREE.AnimationMixer(projectil_alien2[valeur_i][0]);
       // console.log(projectil_alien2[valeur_i][1]);
       let action = projectil_alien2[valeur_i][1].clipAction(clip);
      // console.log(action);
       action.play();
      
       //
       // action.paused =!loopOn;
      }

      export { animation_base,animation_base2,animation_base3,animation_base4,animation_projectil_alien };
  