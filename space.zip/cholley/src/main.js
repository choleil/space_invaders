import * as THREE from 'three'
import LRUCache from 'lru-cache';
import * as TWEEN from 'tween.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { clone } from 'three/examples/jsm/utils/SkeletonUtils.js';

import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import {Pane} from 'tweakpane';
import * as EssentialsPlugin from '@tweakpane/plugin-essentials';

import _, { add } from 'lodash';
import { AxesHelper, BoxHelper } from 'three';

import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader';

import { alien1,alien2,alien3} from './aliens'
import { alien1_menu,alien2_menu,alien3_menu} from './menu'
import { barriers } from './barriers'

import { animation_base } from './animations'
import { animation_base2 } from './animations'
import { animation_base3 } from './animations'
import { animation_base4 } from './animations'
import { animation_projectil_alien } from './animations'


import { scaleModel } from './scale'

const listener = new THREE.AudioListener();
const dracoLoader = new DRACOLoader();
dracoLoader.setDecoderPath( 'node_modules/three/examples/js/libs/draco/');// Spécifier le chemin vers le décodeur Draco

// Créer un chargeur GLTFLoader et lui ajouter le DracoLoader
const gltfLoader = new GLTFLoader();
gltfLoader.setDRACOLoader(dracoLoader);

let touch_i=true;
let projectileTimers = [];

let dead_alien=0;

let audio_arc;

  const loader = new GLTFLoader();

let renderer, scene, camera;
let headData;
let phoenix=true;

let smoke_model,star_model;

let pos_armee=-9;
let pos_armee2=12;
let bool_armee= true;

let mystery_model;
let character_model;

let explosion;
let mouette_model;

let mesh;
 let fin = true;

let lives = 3;
let affichageDiv;
let animation3;

let hearts=[];
const heartContainer = document.querySelector("#heart-container");

let frequence_tir= 3000;

let score = 0;

let mixer1,action1;
let mixer;
const clock = new THREE.Clock();
let loopOn = true;

let egg_model,meteor_model,fish_model,portal_model;

let projectil_model,projectil_model2;
var animation1,animation2;

let head=[];
let body=[];

let chicken=[];
let duck = [];
let owl = [];
let arrow=[];

let cheese = [];
let little_slime = [];
let os = [];

let projectils = [];
let barrier = [];
let projectil_alien = [];
let disparition_alien = [];

let meteor_explosion = [];

let level = 1;

let AddProjectil = true;

const PI =Math.PI;

let axis = new THREE.Vector3(0, 1, 0);
let angle = 0;
let speed = 0.01;

let tir=false;
let phoenix_move=false;

let avancer_x=0.009, avancer_y=0.0001;
let audio_menu,audio_oeuf,audio;
let model = false;

let cam_player=false;


let audio_bird;

function camera_plateau(){

  camera.position.set(0, 80, 80);
  // Incliner la caméra vers le bas de 15 degrés
camera.rotateX(-Math.PI / 12);
  // Faire en sorte que la caméra regarde vers le bas de la scène
  camera.lookAt(0, 0, 0);
}

function camera_lateral(){
  camera.position.set(-75, 18, 0);
  camera.lookAt(0, 0, 0);
}


async function playGame(){
  audio_menu.play();
  //camera.position.set(0, 20, 41);
  //camera.rotation.x=2*PI/3;
  //loop(false);
  if (level==1) frequence_tir= 3000;
  else if (level==2) frequence_tir= 3010;
  else if (level==3) frequence_tir= 3020;
camera_plateau();
//camera_lateral();

  

  level=1;
  score=0;

  document.getElementById("left").innerHTML = '<strong>Level </strong> ' + level + '<br>';
  document.getElementById("center").innerHTML = '<strong>Score </strong> ' + score + '<br>';

  affichageDiv = document.getElementById('right');
lives=3;

affichageDiv.innerHTML = '';

  for (let i = 0; i < 3; i++) {
    const heartDiv = document.createElement('div'); // création d'un nouveau div
    heartDiv.classList.add('heart'); // ajout de la classe "heart" au nouveau div
    affichageDiv.appendChild(heartDiv); // ajout du nouveau div dans le div de classe "right"
  }

  document.getElementById("affichage").style.display = "flex";
  document.getElementById("menu").style.display = "none";
  document.getElementById("menu_alien1").style.display = "none";
  document.getElementById("menu_alien2").style.display = "none";
  document.getElementById("menu_alien3").style.display = "none";
  document.getElementById("menu_alien4").style.display = "none";
  document.getElementById("play").style.display = "none";



  touch_i= false;
  phoenix_move=true;
  fin=false;

  scene.remove(chicken[0][3]);
  scene.remove(duck[0][3]);
  scene.remove(owl[0][3]);

  chicken.splice(0, 1);
  duck.splice(0, 1);
  owl.splice(0, 1);

  scene.remove(mystery_model)

  let string = "<h1>Level            "+level+"</h1>";
  document.getElementById("level").innerHTML =   string + '<br>';
  document.getElementById("level").style.display = "block";

  setTimeout(async function() {
    document.getElementById("level").innerHTML ="";
    document.getElementById("level").style.display = "none"; 
    scene.add(mystery_model);
    chicken=await alien1(chicken,scene);
    duck=await alien2(duck,scene);
    owl = await alien3(owl,scene);
    barrier= barriers(barrier,scene,level);
   // await initAsync();
    //addInstancedMesh();
    //tir_alien();
   // model = true;
    await Promise.all([chicken, duck, owl, barrier,initAsync()]);
    mystery_model.visible=false;

    //loop(loopOn);

}, 2000);


 
 // loop(loopOn);
}

let menu_b = false;


async function menu(){
  //audio_menu.play();
  //if (menu_b)audio_menu.play();

  camera.position.copy(cameraInitialPosition); 
  camera.rotation.copy(cameraInitialRotation);

  document.getElementById("menu").style.display = "flex";
  document.getElementById("menu_alien1").style.display = "flex";
  document.getElementById("menu_alien2").style.display = "flex";
  document.getElementById("menu_alien3").style.display = "flex";
  document.getElementById("menu_alien4").style.display = "flex";
  document.getElementById("play").style.display = "flex";


  loopOn=true;
  document.getElementById("gameover").style.display = "none";
  document.getElementById("fin").style.display = "none";
  document.getElementById("fin_2").style.display = "none";
  
  touch_i= true;
  phoenix_move=false;
  fin=true;
  
  chicken=await alien1_menu(chicken,scene);
  duck=await alien2_menu(duck,scene);
  owl = await alien3_menu(owl,scene);
  model=true;
  scene.add(mystery_model);
  mystery_model.position.y=1;
  mystery_model.position.x=7;
  mystery_model.position.z=10;
  mystery_model.rotation.y=3*PI/2;
  await Promise.all([chicken, duck, owl]);

  loop(loopOn);

}

document.addEventListener('DOMContentLoaded', function() {
  const playButton = document.getElementById('play-button');
  playButton.addEventListener('click', playGame);
});

document.addEventListener('DOMContentLoaded', function() {
  const playButton = document.getElementById('menu-button');
  playButton.addEventListener('click', menu);
  //audio_menu.play();
  //menu_b=true;
});

let cameraInitialPosition,cameraInitialRotation ;

function init() {
  

  document.getElementById("level").style.display = "none";
 



  renderer = new THREE.WebGLRenderer({
    antialias: true,
  });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1;
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.setClearColor(0x87ceeb);


 //document.body.appendChild(renderer.domElement);
 //document.querySelector('#artboard');

 const myDiv = document.getElementById('artboard');

// Add the renderer to the div element
myDiv.appendChild(renderer.domElement);

  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(30, window.innerWidth / window.innerHeight, 0.1, 1000);
 // camera.position.z = 8;
 camera.position.set(0, 6, 41);


  const controls = new OrbitControls(camera, renderer.domElement);
  controls.target.set(0,0,0);
  controls.update();
  controls.addEventListener('change', render);

  cameraInitialPosition = camera.position.clone();
  cameraInitialRotation = camera.rotation.clone();
 // controls.enabled = false;

 



 const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
 directionalLight.position.set(1, 1, 1).normalize();
 scene.add(directionalLight);

 // Add an ambient light to the scene
 const ambientLight = new THREE.AmbientLight(0x404040);
 scene.add(ambientLight);

  scene.add(new THREE.GridHelper(20));
  scene.add(new THREE.AxesHelper(20));
  renderer.setClearColor(0x87ceeb);
  document.getElementById("affichage").style.display = "none";
  

  //render();
}




async function loadMystery(){
  const mystery_data = await loader.loadAsync('.././assets/models/phoenix_bird/scene.gltf');
   mystery_model = mystery_data.scene;
  

   mystery_model.name="mystery";
  scaleModel(mystery_model, mystery_model.scale.x/150);

  mystery_model.position.y=1;
  mystery_model.position.x=7;
  mystery_model.position.z=10;
  mystery_model.rotation.y=3*PI/2;

  mixer = animation_base(mystery_data,mystery_model,mixer);

  scene.add(mystery_model);


  gltfLoader.load( 'http://localhost:5173/assets/models/landscape/output_model.glb', function ( gltf ) {

 
let landscape_model= gltf.scene;
//egg_model.position.y = 0.3;
landscape_model.position.x = 13;
landscape_model.position.y = -0.75;
landscape_model.position.z = 15.5;
landscape_model.rotation.y = PI;
scaleModel(landscape_model, landscape_model.scale.x*4);
scene.add(landscape_model);



}, undefined, function ( error ) {
  console.error( error );
});

  render();


}

async function initAsync() {



 /* const mystery_data = await loader.loadAsync('.././assets/models/phoenix_bird/scene.gltf');
   mystery_model = mystery_data.scene;
  

   mystery_model.name="mystery";
  scaleModel(mystery_model, mystery_model.scale.x/150);*/
  mystery_model.position.y=1;
  mystery_model.position.x=-30;
  mystery_model.position.z=-21;





gltfLoader.load( 'http://localhost:5173/assets/models/arrow/output_model.glb', function ( gltf ) {

 
projectil_model= gltf.scene;

  projectil_model.position.z = 28;
  projectil_model.position.y = 0.8;//1.2
  projectil_model.rotation.y=PI/2;
   
   scaleModel(projectil_model, projectil_model.scale.x*0.6);

  // scene.add(projectil_model)
 

}, undefined, function ( error ) {
  console.error( error );
});


gltfLoader.load( 'http://localhost:5173/assets/models/archer_fem_attack_-_medieval_fantasy_challenge/output_model.glb', function ( gltf ) {
  character_model= gltf.scene;
  character_model.position.z = 30;
character_model.rotation.y=PI;

scene.add(character_model);
    

}, undefined, function ( error ) {
  console.error( error );
});







//scene.add(mystery_model);

gltfLoader.load( 'http://localhost:5173/assets/models/smoke/output_model.glb', function ( gltf ) {

smoke_model= gltf.scene;
//egg_model.position.y = 0.3;
scaleModel(smoke_model, smoke_model.scale.x*3);
animation3=gltf.animations;
//console.log("animationnnn"+animation1);*/
//scene.add(mouette_model);
//scene.add(smoke_model);




}, undefined, function ( error ) {
  console.error( error );
});

gltfLoader.load( 'http://localhost:5173/assets/models/magical_orb/output_model.glb', function ( gltf ) {

portal_model= gltf.scene;
portal_model.position.z = -21.7;
portal_model.position.y = 1.75;
portal_model.position.x = 23.2;
scaleModel(portal_model, portal_model.scale.x*22);
/*animation1=gltf.animations;
console.log("animationnnn"+animation1);*/
//scene.add(mouette_model);
scene.add(portal_model);




}, undefined, function ( error ) {
  console.error( error );
});






gltfLoader.load( 'http://localhost:5173/assets/models/egg/output_model.glb', function ( gltf ) {

egg_model= gltf.scene;
egg_model.position.y = 0.3;
scaleModel(egg_model, egg_model.scale.x*0.5);
animation1=gltf.animations;
//console.log("animationnnn"+animation1);
//scene.add(egg_model);



}, undefined, function ( error ) {
  console.error( error );
});







/*let cheese_data = await loader.loadAsync('.././assets/models/cheese/scene.gltf');
  let cheese_model2 = cheese_data.scene;*/


 /*let slime_data = await loader.loadAsync('.././assets/models/slime/scene.gltf');
 let slime_model2 = slime_data.scene;*/

/* let os_data = await loader.loadAsync('.././assets/models/femur_os_femoris_juvenile_sheep/scene.gltf');
 let os_model2 = os_data.scene;*/

/*for (let i = 0;i <7;i++){

  let cheese_model = clone(cheese_model2);
  //let name = "duck"+i.toString();
  //duck_model.name=name;
cheese_model.position.y =0.72; 
 cheese.push(cheese_model);
  scaleModel(cheese_model, cheese_model.scale.x*0.3);
 // scene.add(cheese[i]);


  let slime_model = clone(slime_model2);
  //let name = "duck"+i.toString();
  //duck_model.name=name;
slime_model.position.y =0.9; 
 little_slime.push(slime_model);
  scaleModel(slime_model, slime_model.scale.x*0.6);
 // scene.add(little_slime[i]);

  let os_model = clone(os_model2);
  //let name = "duck"+i.toString();
  //duck_model.name=name;
os_model.position.y =0.9; 
//os_model.position.z =20; 
 os.push(os_model);
  scaleModel(os_model, os_model.scale.x/22000);
 // console.log(os);
 //scene.add(os[i]);
  
}*/





 //scene.add(Alien_1_Model);
 //mixer = animation_base(mystery_data,mystery_model,mixer);
 //animation_base1(character_data,character_model);
/*animation_base2(chicken);
animation_base3(duck);
animation_base4(owl);
*/


/*
for (let i = 0; i < 4; i++) {
 const barrierBlock2 = GroupC.clone();
  barrierBlock2.position.x = -10+i*6.8;
  barrierBlock2.position.y = 0.5; // ajuster la position verticale ici
  barrierBlock2.position.z = 25;
  
  scene.add(barrierBlock2);
}*/


//console.log(barrier);


  //          n1
  //      6________ 7
  //      /|  n3  /|
  //    4/_|_____/5| n5
  //  n4 | |_____|_|
  //     |2/ n0  | /3
  //     |/______|/
  //    0    n2   1



/*
  const xRange = [0, 2.25];
  const yRange = [0, 1.5];
  const ZRange = [0,0.75];

  const vData = [];

  yRange.forEach(y => {
    xRange.forEach(x => {
      ZRange.forEach(z => {
       vData.push([z, y, x]);
      });
    });
  });




  const nData = {
    0: [0, 0, -1],
    1: [0, 0, 1],
    2: [0, -1, 0],
    3: [0, 1, 0],
    4: [-1, 0, 0],
    5: [1, 0, 0],
  };

  const Vindice = [
    0, 3, 1,
    0, 2, 3,
    5, 6, 4,
    5, 7, 6,
    1, 4, 0,
    1, 5, 4,
    2, 7, 3,
    2, 6, 7,
    6, 0, 4,
    6, 2, 0,
    3, 5, 1,
    3, 7, 5,
  ];


  const Nindice = [];

  let l = 0;

  while (l < 36) {
    for (let k = 0; k < 6; k++) {
      Nindice.push(Vindice[l]);
      Nindice.push(Vindice[l + 1]);
      Nindice.push(Vindice[l + 2]);

    }
    l++;

  }

  const vertices = Vindice.map(v => vData[v]).flat();
  const normals = Nindice.map(n => nData[n]).flat();


  const geometry = new THREE.BufferGeometry();

  geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));

  const walls = new THREE.Mesh(geometry, barrierMaterial);

/*
  walls.position.x = -10+6.8;
  walls.position.y = 0.5;
  walls.position.y = 25;*/


/*
  walls.castShadow = true;
  walls.receiveShadow = false;

  geometry.computeVertexNormals();
  scene.add(walls)*/
  //return walls;







//animation_base(Alien_1_Data2,Alien_1_Model2,2);

//animation_base(Alien_1_Data,Alien_1_Model,1);
  
  //scene.add(Alien_1_Model,headModel);
  //render();
}

//var mesh = null;

/*
var dummy = new THREE.Object3D();
var sectionWidth = 5;

function addInstancedMesh() {
  // An InstancedMesh of 4 cubes
  //mesh = new THREE.InstancedMesh(new THREE.BoxBufferGeometry(3,3,3), new THREE.MeshNormalMaterial(), 4);
  const duck_geometry = duck_data.scene.children[0].geometry;
const duck_material = duck_data.scene.children[0].material;

  mesh = new THREE.InstancedMesh(duck_geometry, duck_material, 25);
  scene.add(mesh);
  setInstancedMeshPositions(mesh);
}

function setInstancedMeshPositions(mesh) {
  for ( var i = 0; i < mesh.count; i ++ ) {
    // we add 200 units of distance (the width of the section) between each.
    var xStaticPosition = -sectionWidth * (i - 1)
    dummy.position.set(xStaticPosition, 0, 0);
    dummy.scale.set(2, 2, 2); 
    dummy.updateMatrix();
    mesh.setMatrixAt( i, dummy.matrix );
  }
  mesh.instanceMatrix.needsUpdate = true;
}*/


function initAsync2(){
  mystery_model.position.y=1;
  mystery_model.position.x=-30;
  mystery_model.position.z=-21;
  scene.add(mystery_model);

  character_model.position.x = 0;
  scene.add(character_model);

}








async function detectCollisions2() {
  
  /*  perso.translate(projectil_alien);
    const expansionVector = new THREE.Vector3(0.5, 0.5, 0.5);
    perso.expandByVector(expansionVector);*/

    let touche = false;

    let projectil;

  for (let i = 0; i < projectil_alien.length; i++) {
    const projectileBox = new THREE.Box3().setFromObject(projectil_alien[i][0]);
    /*projectileBox.translate(projectil_alien);

    const expansionVector = new THREE.Vector3(1, 1, 1);
    projectileBox.expandByVector(expansionVector); */

//console.log("ca test");
    for (let j = 0; j < barrier.length; j++) {
      const barrierBox = new THREE.Box3().setFromObject(barrier[j]);
      if (projectileBox.intersectsBox(barrierBox)) {
        
        scene.remove(barrier[j]);
        barrier.splice(j, 1);
        //scene.remove(projectil_alien[i][0]);
       animation_projectil_alien(projectil_alien,i);
       let anim_model=projectil_alien[i][0];

        setTimeout(function() {
          for (let aa =0;aa<projectil_alien.length;aa++){
            console.log("dispaaaaa");
            if (projectil_alien[aa][0]==anim_model){
              scene.remove(projectil_alien[aa][0]);
              projectil_alien.splice(aa, 1);
              break;
            }
          }
          
        }, 1000);
        
        //projectil_alien.splice(i, 1);
      
        
        break;
       
      }
    }

    //regler pb oeuf qui se pete direct
    for (let j = 0; j < projectils.length; j++) {
      const projectileBox2 = new THREE.Box3().setFromObject(projectils[j]);

            if (projectileBox.intersectsBox(projectileBox2)) {
        
        scene.remove(projectils[j]);
        projectils.splice(j, 1);
        //scene.remove(projectil_alien[i][0]);
        animation_projectil_alien(projectil_alien,i);
       let anim_model=projectil_alien[i][0];

        setTimeout(function() {
          for (let aa =0;aa<projectil_alien.length;aa++){
            console.log("dispaaaaa");
            if (projectil_alien[aa][0]==anim_model){
              scene.remove(projectil_alien[aa][0]);
              projectil_alien.splice(aa, 1);
              break;
            }
          }
          
        }, 1000);
        
        break;
       
      }


    }

    const perso_box = new THREE.Box3().setFromObject(character_model);

    if ((!touch_i)&&(!touche)){

     
  if (projectileBox.intersectsBox(perso_box)) {

    if (audio_oeuf.isPlaying) {
      audio_oeuf.stop(); // arrête la lecture
    }
    audio_oeuf.play(); // d
    console.log("aaaa");
    touche=true;

    projectil=clone(egg_model);

    projectil.position.x=projectil_alien[i][0].position.x;
    projectil.position.z=projectil_alien[i][0].position.z;

    let egg = disparition_alien.length;
   // console.log(animation1);
   disparition_alien.push([projectil,0,animation1]);
    animation_projectil_alien(disparition_alien,egg);

    let anim_model= disparition_alien[egg][0];

    setTimeout(function() {
      for (let aa =0;aa< disparition_alien.length;aa++){
        console.log("dispaaaaa");
        if ( disparition_alien[aa][0]==anim_model){
          scene.remove( disparition_alien[aa][0]);
          disparition_alien.splice(aa, 1);
          if (lives ==0){
            fin_level();
            document.getElementById("fin").innerHTML='Game Over <br>Score: '+score;
            document.getElementById("fin").style.display = "block";
            document.getElementById("gameover").style.display = "block";
            document.getElementById("affichage").style.display = "none";
            model=false;       
          }
          break;
        }
      }
      
    }, 1000);

   /* setTimeout(function() {


      scene.remove(disparition_alien[egg][0]);
      disparition_alien.splice(i, 1);

  

     /* if (lives ==0){
        fin_level();
        document.getElementById("fin").innerHTML='Game Over <br>Score: '+score;
        document.getElementById("fin").style.display = "block";
        document.getElementById("gameover").style.display = "block";
        document.getElementById("affichage").style.display = "none";
        model=false;       
      }*/
    
    //}, 1000);
    console.log(disparition_alien);    

    scene.add(projectil);

    scene.remove(projectil_alien[i][0]);
    //scene.remove(duck[j][3]);
    projectil_alien.splice(i, 1);


    lives--;
    affichageDiv.innerHTML = "";
   // console.log("les vies"+lives);
    
    for (let i = 0; i < lives; i++) {
      const heartDiv = document.createElement('div');
      heartDiv.classList.add('heart');
      affichageDiv.appendChild(heartDiv);
    
    }


  //  duck.splice(j, 1);

  
    //scene.remove(projectil_alien[i][0]);
   /* animation_projectil_alien(projectil_alien,i);
    let anim_model=projectil_alien[i][0];
    //anim_model.id = 'anim-model';

     setTimeout(function() {
       for (let aa =0;aa<projectil_alien.length;aa++){
         console.log("dispaaaaa");
         if (projectil_alien[aa][0]==anim_model){
           scene.remove(projectil_alien[aa][0]);
           projectil_alien.splice(aa, 1);

         

          if (scene.getObjectById(anim_model.id)==undefined){
            lives--;
            affichageDiv.innerHTML = "";
           // console.log("les vies"+lives);
            
            for (let i = 0; i < lives; i++) {
              const heartDiv = document.createElement('div');
              heartDiv.classList.add('heart');
              affichageDiv.appendChild(heartDiv);
            
            }

            if (lives ==0){
              fin_level();
              document.getElementById("fin").style.display = "block";
              document.getElementById("gameover").style.display = "block";
              document.getElementById("affichage").style.display = "none";
              model=false;       
            }

          }
           break;
         }
       }
       
     }, 1000);
    


*/


  //projectil_alien.splice(i, 1);
    
  }
}

  }

}

async function detectCollisions() {
  const mystery = new THREE.Box3().setFromObject(mystery_model);
  

  for (let i = 0; i < projectils.length; i++) {
    let tampon = projectils[i];
const projectileBox = new THREE.Box3().setFromObject(projectils[i]);

if (projectileBox.intersectsBox(mystery)) {
  if (audio_oeuf.isPlaying) {
    audio_oeuf.stop(); // arrête la lecture
  }
  audio_oeuf.play(); //
  let projectil=clone(smoke_model);

  scene.remove(mystery_model);



 // scene.remove(projectils[i]);
  //projectils.splice(i, 1);

  for (let aa =0;aa< projectils.length;aa++){
    console.log("dispaaaaa");
    if ( projectils[aa][0]==tampon){
      scene.remove(projectils[aa]);
      projectils.splice(aa, 1);
     
      break;
    }
  }

  projectil.position.x = mystery_model.position.x;
  projectil.position.z = mystery_model.position.z;


  let egg = disparition_alien.length;
  // console.log(animation1);
  disparition_alien.push([projectil,0,animation3]);
   animation_projectil_alien(disparition_alien,egg);

   let anim_model= disparition_alien[egg][0];

   setTimeout(function() {
     for (let aa =0;aa< disparition_alien.length;aa++){
       console.log("dispaaaaa");
       if ( disparition_alien[aa][0]==anim_model){
         scene.remove( disparition_alien[aa][0]);
         disparition_alien.splice(aa, 1);
         if (lives ==0){
           fin_level();
           document.getElementById("fin").innerHTML='Game Over <br>Score: '+score;
           document.getElementById("fin").style.display = "block";
           document.getElementById("gameover").style.display = "block";
           document.getElementById("affichage").style.display = "none";
           model=false;       
         }
         break;
       }
     }
     
   }, 1000);

  /* setTimeout(function() {
     scene.remove(disparition_alien[egg][0]);
     disparition_alien.splice(i, 1);
   }, 1000);
   console.log(disparition_alien);    */

   scene.add(projectil);

  score+=80;
  document.getElementById("center").innerHTML = '<strong>Score </strong> ' + score + '<br>';

  //(scene.getObjectById(anim_model.id)==undefined)

   if (scene.getObjectById(mystery_model.id)==undefined&&(dead_alien==55)||(dead_alien==56)){
  fin_level();
  // level++;
   document.getElementById("left").innerHTML = '<strong>Level </strong> ' + level + '<br>';

   new_level();
   }
}



for (let j = 0; j < chicken.length; j++) {
  const alienBox2 = new THREE.Box3().setFromObject(chicken[j][3]);

  alienBox2.translate(chicken[j][3].position);

  const expansionVector = new THREE.Vector3(0.8, 0.8, 0.8);
alienBox2.expandByVector(expansionVector); 
 /* console.log(alienBox2);

  const center = alienBox2.getCenter(new THREE.Vector3());
  alienBox2.translate(-center.x, -center.y, -center.z);*/
 
  if (projectileBox.intersectsBox(alienBox2)) {
    // Si les boîtes englobantes se chevauchent, supprimer le projectile et l'alien de la scène
    if (audio_oeuf.isPlaying) {
      audio_oeuf.stop(); // arrête la lecture
    }
    audio_oeuf.play(); //
   scene.remove(projectils[i]);
    scene.remove(chicken[j][3]);

    projectils.splice(i, 1);
    chicken.splice(j, 1);

    /*for (let aa =0;aa< projectils.length;aa++){
      console.log("dispaaaaa");
      if ( projectils[aa][0]==tampon){
        scene.remove(projectils[aa]);
        projectils.splice(aa, 1);
       
        break;
      }
    }*/
  
    let projectil=clone(egg_model);
scaleModel(projectil, projectil.scale.x*1.5);
   
    projectil.position.x=chicken[j][3].position.x-1.5;
    projectil.position.z=chicken[j][3].position.z+1;

    let egg = disparition_alien.length;
   // console.log(animation1);
   disparition_alien.push([projectil,0,animation1]);
    animation_projectil_alien(disparition_alien,egg);

    let anim_model= disparition_alien[egg][0];

    setTimeout(function() {
      for (let aa =0;aa< disparition_alien.length;aa++){
        console.log("dispaaaaa");
        if ( disparition_alien[aa][0]==anim_model){
          scene.remove( disparition_alien[aa][0]);
          disparition_alien.splice(aa, 1);
          break;
        }
      }
      
    }, 1000);

    dead_alien++;

    /*setTimeout(function() {
      scene.remove(disparition_alien[egg][0]);
      disparition_alien.splice(i, 1);
    }, 1000);*/
   

    scene.add(projectil);
    score+=10;
    document.getElementById("center").innerHTML = '<strong>Score </strong> ' + score + '<br>';

   // if ((scene.contains(mystery_model)&&(dead_alien==55))||(dead_alien==56)){
    if (scene.getObjectById(mystery_model.id)==undefined&&(dead_alien==55)||(dead_alien==56)){
      fin_level();
      // level++;
       document.getElementById("left").innerHTML = '<strong>Level </strong> ' + level + '<br>';
    
       new_level();
       }
   // console.log(projectils);

    break;

  }

  for (let j = 0; j < barrier.length; j++) {
    const barrierBox = new THREE.Box3().setFromObject(barrier[j]);
  //  console.log(barrierBox);
    if (alienBox2.intersectsBox(barrierBox)) {
    
      scene.remove(barrier[j]);   
      barrier.splice(j, 1);

      break;
     
    }
  }
  const perso_box = new THREE.Box3().setFromObject(character_model);
  if (alienBox2.intersectsBox(perso_box)) {
    affichageDiv.innerHTML = "";

    fin_level();
    document.getElementById("fin").innerHTML='Game Over <br>Score: '+score;
    document.getElementById("fin").style.display = "block";
    document.getElementById("gameover").style.display = "block";
    document.getElementById("affichage").style.display = "none";
    loopOn=false;
  }
}
    for (let j = 0; j < duck.length; j++) {
      const alienBox = new THREE.Box3().setFromObject(duck[j][3]);
      //console.log(alienBox)
      if (projectileBox.intersectsBox(alienBox)) {
        // Si les boîtes englobantes se chevauchent, supprimer le projectile et l'alien de la scène
        if (audio_oeuf.isPlaying) {
          audio_oeuf.stop(); // arrête la lecture
        }
        audio_oeuf.play(); //
    let projectil=clone(egg_model);
    scaleModel(projectil, projectil.scale.x*1.5);
    dead_alien++;

        projectil.position.x=duck[j][3].position.x;
        projectil.position.z=duck[j][3].position.z+1;
    
        let egg = disparition_alien.length;
       // console.log(animation1);
       disparition_alien.push([projectil,0,animation1]);
        animation_projectil_alien(disparition_alien,egg); 

        let anim_model= disparition_alien[egg][0];

        setTimeout(function() {
          for (let aa =0;aa< disparition_alien.length;aa++){
            console.log("dispaaaaa");
            if ( disparition_alien[aa][0]==anim_model){
              scene.remove( disparition_alien[aa][0]);
              disparition_alien.splice(aa, 1);

              break;
            }
          }
          
        }, 1000);
    
        scene.add(projectil);

        scene.remove(projectils[i]);
        scene.remove(duck[j][3]);

  
       projectils.splice(i, 1);
        duck.splice(j, 1);

       /* for (let aa =0;aa< projectils.length;aa++){
          console.log("dispaaaaa");
          if ( projectils[aa][0]==tampon){
            scene.remove(projectils[aa]);
            projectils.splice(aa, 1);
           
            break;
          }
        }*/
  
        console.log(projectils);
        console.log(duck[j][3]);
        score+=20;
        document.getElementById("center").innerHTML = '<strong>Score </strong> ' + score + '<br>';

        //if (scene.contains(mystery_model)&&(dead_alien==55)||(dead_alien==56)){
          if (scene.getObjectById(mystery_model.id)==undefined&&(dead_alien==55)||(dead_alien==56)){
          fin_level();
          // level++;
           document.getElementById("left").innerHTML = '<strong>Level </strong> ' + level + '<br>';
        
           new_level();
           }
        break;

      }
      for (let j = 0; j < barrier.length; j++) {
        const barrierBox = new THREE.Box3().setFromObject(barrier[j]);
      //  console.log(barrierBox);
        if (alienBox.intersectsBox(barrierBox)) {
          scene.remove(barrier[j]);   
          barrier.splice(j, 1);
          break;
         
        }
      }
      const perso_box = new THREE.Box3().setFromObject(character_model);
      if (alienBox.intersectsBox(perso_box)) {
        affichageDiv.innerHTML = "";
    
        fin_level();
        document.getElementById("fin").innerHTML='Game Over <br>Score: '+score;
        document.getElementById("fin").style.display = "block";
        document.getElementById("gameover").style.display = "block";
        document.getElementById("affichage").style.display = "none";
        loopOn=false;
      }
    }

    for (let j = 0; j < owl.length; j++) {
      const alienBox2 = new THREE.Box3().setFromObject(owl[j][3]);

      alienBox2.translate(owl[j][3].position);
      const expansionVector = new THREE.Vector3(0.5, 0.5, 0.5);
    alienBox2.expandByVector(expansionVector); 

      if (projectileBox.intersectsBox(alienBox2)) {
        dead_alien++;
        if (audio_oeuf.isPlaying) {
          audio_oeuf.stop(); // arrête la lecture
        }
        audio_oeuf.play(); //
        // Si les boîtes englobantes se chevauchent, supprimer le projectile et l'alien de la scène
       scene.remove(projectils[i]);
        scene.remove(owl[j][3]);
        projectils.splice(i, 1);
        owl.splice(j, 1);
        console.log("caaaa");
       // console.log(projectils);

       /*for (let aa =0;aa< projectils.length;aa++){
        console.log("dispaaaaa");
        if ( projectils[aa][0]==tampon){
          scene.remove(projectils[aa]);
          projectils.splice(aa, 1);
         
          break;
        }
      }*/

       let projectil=clone(egg_model);
       scaleModel(projectil, projectil.scale.x*1.5);
          
           projectil.position.x=owl[j][3].position.x-1.5;
           projectil.position.z=owl[j][3].position.z+1;
       
           let egg = disparition_alien.length;
          // console.log(animation1);
          disparition_alien.push([projectil,0,animation1]);
           animation_projectil_alien(disparition_alien,egg);
       
           let anim_model= disparition_alien[egg][0];

           setTimeout(function() {
             for (let aa =0;aa< disparition_alien.length;aa++){
               console.log("dispaaaaa");
               if ( disparition_alien[aa][0]==anim_model){
                 scene.remove( disparition_alien[aa][0]);
                 disparition_alien.splice(aa, 1);
                
                 break;
               }
             }
             
           }, 1000);
       
           scene.add(projectil);
           score+=30;
           document.getElementById("center").innerHTML = '<strong>Score </strong> ' + score + '<br>';

           //if (scene.contains(mystery_model)&&(dead_alien==55)||(dead_alien==56)){
            if (scene.getObjectById(mystery_model.id)==undefined&&(dead_alien==55)||(dead_alien==56)){

            fin_level();
            // level++;
             document.getElementById("left").innerHTML = '<strong>Level </strong> ' + level + '<br>';
          
             new_level();
             }
 
        break;

      }
      for (let j = 0; j < barrier.length; j++) {
        const barrierBox = new THREE.Box3().setFromObject(barrier[j]);
      //  console.log(barrierBox);
        if (alienBox2.intersectsBox(barrierBox)) {
          scene.remove(barrier[j]);   
          barrier.splice(j, 1);
          break;
         
        }
      }
      const perso_box = new THREE.Box3().setFromObject(character_model);
      if (alienBox2.intersectsBox(perso_box)) {
        affichageDiv.innerHTML = "";
    
        fin_level();
        document.getElementById("fin").innerHTML='Game Over <br>Score: '+score;
        document.getElementById("fin").style.display = "block";
        document.getElementById("gameover").style.display = "block";
        document.getElementById("affichage").style.display = "none";
        loopOn=false;
      }

    }

    for (let j = 0; j < barrier.length; j++) {
      const barrierBox = new THREE.Box3().setFromObject(barrier[j]);
    //  console.log(barrierBox);
      if (projectileBox.intersectsBox(barrierBox)) {
        console.log("weshhh");
        // Le projectile a touché le mur, donc nous devons créer un trou à cet endroit
       
    
        let projectil=clone(egg_model);
        scaleModel(projectil, projectil.scale.x*0.5);
           
            projectil.position.x=projectils[i].position.x;
            projectil.position.z=projectils[i].position.z-0.25;
            projectil.position.y=projectils[i].position.y;
        
            let egg = disparition_alien.length;
            // console.log(animation1);
            disparition_alien.push([projectil,0,animation1]);
             animation_projectil_alien(disparition_alien,egg);
             let anim_model= disparition_alien[egg][0];
            setTimeout(function() {
              for (let aa =0;aa< disparition_alien.length;aa++){
                console.log("dispaaaaa");
                if ( disparition_alien[aa][0]==anim_model){
                  scene.remove( disparition_alien[aa][0]);
                  disparition_alien.splice(aa, 1);
                 
                  break;
                }
              }
              
            }, 1000);
        
            scene.add(projectil);


            scene.remove(barrier[j]);
            scene.remove(projectils[i]);

           projectils.splice(i, 1);
        /*  for (let aa =0;aa< projectils.length;aa++){
            console.log("dispaaaaa");
            if ( projectils[aa][0]==tampon){
              scene.remove(projectils[aa]);
              projectils.splice(aa, 1);
             
              break;
            }
          }*/
            barrier.splice(j, 1);

        break;
       
      }
    }


  }
  
}






async function tir_alien(){

  
  let i =Math.floor(Math.random() * 3);
  console.log("ale i"+i);

 //let i =0;
  let obj = true;
  let projectil;
  let j =0;
  let alien;
  console.log(i);
  

  // Vérifier si l'objet est défini avant d'utiliser la méthode clone
if (egg_model !== undefined) {
  projectil=clone(egg_model);


} else {
  return;
}


  if (i ==0){
    //projectil=clone(egg_model);

    alien = Math.floor(Math.random() * chicken.length-1);
    if (alien!=-1){
    console.log("aaahhahahh"+alien);
    projectil.position.x=chicken[alien][3].position.x;
    projectil.position.z=chicken[alien][3].position.z;
    projectil_alien.push([projectil,0,animation1]);
    scene.add(projectil);
    }

  }

  
  if (i ==1){
  //  projectil=clone(fish_model);
alien = Math.floor(Math.random() * duck.length-1);
console.log("aaahhahahh"+alien);
if (alien!=-1){
projectil.position.x=duck[alien][3].position.x;
projectil.position.z=duck[alien][3].position.z;
projectil_alien.push([projectil,0,animation1]);
scene.add(projectil);
}
  }

  if (i ==2){
alien = Math.floor(Math.random() * owl.length-1);
if (alien!=-1){
console.log("aaahhahahh"+alien);
projectil.position.x=owl[alien][3].position.x;
projectil.position.z=owl[alien][3].position.z;
projectil_alien.push([projectil,0,animation1]);
scene.add(projectil);

  }
}


}

let test_alien = false;
let lastProjectileTime = 0;
const projectileDelay = 3; // délai en secondes entre chaque projectile

async function render() {
 /* if (mystery_model.position.x>=-20)mystery_model.position.x-=0.05;
  else if (mystery_model.position.x<=20)mystery_model.position.x+=0.05;*/
  
 // await Promise.all([detectCollisions(),detectCollisions2()]);
if (!test_alien){
if (dead_alien==11){
  test_alien=true;
  avancer_x +=0.0009;
  avancer_y+=0.0003;
  frequence_tir-=200;
}
}

  //tir_alien();
  if (!touch_i){
  if (phoenix){
    if (mystery_model.position.x>=-28) {
      mystery_model.visible=true;
      if (!audio_bird.isPlaying) audio_bird.play();
    }

    if (mystery_model.position.x>=28) {
      if (audio_bird.isPlaying) audio_bird.stop();

    }
    mystery_model.position.x+=0.05;
    mystery_model.rotation.y=0;
    if (mystery_model.position.x>=40){
      phoenix=false;
    
    }
  }
  else{
    if (mystery_model.position.x<=-28) {
      mystery_model.visible=false;
      if (audio_bird.isPlaying) audio_bird.stop();
    }

    if (mystery_model.position.x<=28) {
      if (!audio_bird.isPlaying) audio_bird.play();
    }
    mystery_model.position.x-=0.05;
    mystery_model.rotation.y=PI;
    if (mystery_model.position.x<=-40){
      phoenix=true;
      
    }
  }
  }
 /* angle += speed;
 projectil_model.rotateOnAxis(axis, speed);*/
  
 /* projectil_model.position.z =0;
  projectil_model.position.y =0;
 // projectil_model.position.y += 0.04;
projectil_model.rotation.x+=0.01;
//projectil_model.position.z -=0.38;
//projectil_model.position.y -= 0.04;
projectil_model.position.y =0;
projectil_model.position.z =0;*/
//projectil_model.rotation.z -=0.02;
  const delta = clock.getDelta();
  for(let i=0;i<chicken.length;i++){
    if (chicken[i][1]){
      chicken[i][2].update(delta);
      if(!touch_i){
     if (bool_armee){
        chicken[i][3].position.x+=avancer_x;
      }
      else{
        chicken[i][3].position.x-=avancer_x;
      }
     // chicken[i][3].position.x+=0.1;
      chicken[i][3].position.z+=avancer_y;

      if (chicken[i][3].position.Z>=32){
        affichageDiv.innerHTML = "";

           fin_level();
           document.getElementById("fin").innerHTML='Game Over <br>Score: '+score;
           document.getElementById("fin").style.display = "block";
           document.getElementById("gameover").style.display = "block";
           document.getElementById("affichage").style.display = "none";
           loopOn=false;
       
      }
    }
  }

  }
 for(let i=0;i<duck.length;i++){
  if (duck[i][1]){
    duck[i][2].update(delta);
    if(!touch_i){
    if (bool_armee){
      duck[i][3].position.x+=avancer_x;
    }
    else{
      duck[i][3].position.x-=avancer_x;
    }
   // chicken[i][3].position.x+=0.1;
    duck[i][3].position.z+=avancer_y;

    if (duck[i][3].position.Z>=32){
      affichageDiv.innerHTML = "";

         fin_level();
         document.getElementById("fin").innerHTML='Game Over <br>Score: '+score;
         document.getElementById("fin").style.display = "block";
         document.getElementById("gameover").style.display = "block";
         document.getElementById("affichage").style.display = "none";
         loopOn=false;
     
    }
  }
}

    }
    for(let i=0;i<owl.length;i++){
      if (owl[i][1]){

        owl[i][2].update(delta);
        if(!touch_i){
        if (bool_armee){
          owl[i][3].position.x+=avancer_x;
        }
        else{
          owl[i][3].position.x-=avancer_x;
        }
       // chicken[i][3].position.x+=0.1;
        owl[i][3].position.z+=avancer_y;

        if (owl[i][3].position.Z>=32){
          affichageDiv.innerHTML = "";

             fin_level();
             document.getElementById("fin").innerHTML='Game Over <br>Score: '+score;
             document.getElementById("fin").style.display = "block";
             document.getElementById("gameover").style.display = "block";
             document.getElementById("affichage").style.display = "none";
             loopOn=false;
         
        }
      }
      }
        }

        for (let i = 0;i<projectil_alien.length;i++){
          if (projectil_alien[i][1]!=0) {
            console.log("coucouaaaaaaaaaaaaa");
            projectil_alien[i][1].update(delta);
            continue; // Ignore la mise à jour de la position si l'animation est en cours
        }
            projectil_alien[i][0].position.z+=0.2;
            projectil_alien[i][0].rotation.x+=0.2;
           /* if  (projectil_alien[i][1]!=0){
              console.log("coucouuu");
              projectil_alien[i][1].update(delta);
            } */
           
            if (projectil_alien[i][0].position.z >=32) scene.remove(projectil_alien[i][0]);
            if (fin){
              scene.remove(projectil_alien[i][0]);
              projectil_alien.splice(i, 1);

            }
        }


       for (let i = 0;i<disparition_alien.length;i++){
         
            disparition_alien[i][1].update(delta);
   
            if (fin){
              scene.remove(disparition_alien[i][0]);
              disparition_alien.splice(i, 1);

            }
        }





   mixer.update(delta);
   //mixer1.update(delta);

   if (tir){

    for (let i = 0; i < projectils.length; i++) {
    projectils[i].position.z -=0.2;
    if (projectils[i].position.z<=-40){
      scene.remove(projectils[i]);
      projectils.splice(i,1);
    }

    }
   }
if (bool_armee){
  pos_armee+=0.01;
  pos_armee2+=0.01;
  if (pos_armee2>=15){
    bool_armee=false;
  }
}
else {
  pos_armee-=0.01;
  pos_armee2-=0.01;
  if (pos_armee<=-12){
    bool_armee=true;
  }
}


await Promise.all([detectCollisions(),detectCollisions2()]);
/*setTimeout(function() {
  
  if (model) {
    console.log("eheh");
    if (!fin)tir_alien();
  
  }
}, 3000);*/

const currentTime = Date.now();
if (currentTime - lastExecutionTime >= frequence_tir) {
  // Code à exécuter toutes les 3 secondes
  console.log("Fonction exécutée toutes les 3 secondes");
  if (model) {
    if (!fin)await tir_alien();
  }
  lastExecutionTime = currentTime;
}


  renderer.render(scene, camera);
}

function loop(isOn) {
  clock.getDelta();
  renderer.setAnimationLoop( !isOn ? null : render);
  }
  let lastExecutionTime = 0;

 


 async function new_level(){
  //loop(!loopOn);
  if (level<=3){
let string = "<h1>Level            "+level+"</h1>";
  document.getElementById("level").innerHTML =   string + '<br>';
  document.getElementById("level").style.display = "block";
  setTimeout(async function() {
    document.getElementById("level").innerHTML ="";
    document.getElementById("level").style.display = "none";
    if (level==2){
      avancer_x=0.01;
      avancer_y=0.001;
      }
    
      else{
      avancer_x=0.01;
      avancer_y=0.003;
      }
      
    scene.add(mystery_model);
    mystery_model.position.x = 40;
      fin=false;
        chicken=await alien1(chicken,scene);
        duck=await alien2(duck,scene);
        owl = await alien3(owl,scene);
        barrier= barriers(barrier,scene,level);
        initAsync2();
        //addInstancedMesh();
        //tir_alien();
        model = true;
      dead_alien=0;
        await Promise.all([chicken, duck, owl, barrier]);
        loop(loopOn);
        touch_i=false;
    
}, 2000);
  }
  else {
    scene.remove(mystery_model);
    scene.remove(character_model);
  //  document.getElementById("fin_2").innerHTML+='<br>Score: '+score;
  document.getElementById("fin").innerHTML='You win <br>Score: '+score;
    document.getElementById("fin_2").style.display = "block";
    document.getElementById("gameover").style.display = "block";
    document.getElementById("affichage").style.display = "none";

  }

  
  }


  function audio_musique(){

camera.add(listener); // si vous utilisez une caméra dans votre scène

const audioLoader = new THREE.AudioLoader();
audioLoader.load('.././assets/models/musique.mp3', function(buffer) {
  audio = new THREE.Audio(listener);
  audio.setBuffer(buffer);
  audio.setLoop(true);
  audio.setVolume(0.3);
  audio.play();

  // écouter l'événement "ended" pour réinitialiser la lecture
  audio.source.onended = function() {
    audio.play();
  }
});

//const audioLoader2 = new THREE.AudioLoader();

// charger le fichier audio
audioLoader.load('.././assets/models/boutton.mp3', function(buffer) {
  // créer un objet Audio et définir son buffer
 audio_menu = new THREE.Audio(listener);
  audio_menu.setBuffer(buffer);
  audio_menu.setVolume(3);

  // jouer le son lorsque l'utilisateur clique sur le bouton
  const button = document.getElementById('menu-button');
  button.addEventListener('click', function() {
    audio.play();
  });

 
});

  

  audioLoader.load('.././assets/models/audio_arc.mp3', function(buffer) {
    // créer un objet Audio et définir son buffer
   audio_arc = new THREE.Audio(listener);
    audio_arc.setBuffer(buffer);
    audio_arc.setVolume(3);
  });
  
  audioLoader.load('.././assets/models/oeuf.mp3', function(buffer) {
    // créer un objet Audio et définir son buffer
   audio_oeuf = new THREE.Audio(listener);
    audio_oeuf.setBuffer(buffer);
    audio_oeuf.setVolume(2);
    audio_oeuf.playbackRate = 1.5;
  });

  audioLoader.load('.././assets/models/Sons_Aigle.mp3', function(buffer) {
    // créer un objet Audio et définir son buffer
   audio_bird = new THREE.Audio(listener);
    audio_bird.setBuffer(buffer);
    audio_bird.setVolume(0.5);
   
  });

    }



  async function main() {


    

    init();
    await loadMystery();
    await menu();
    audio_musique();
    model = true;




   
    /*loopOn=true;
    document.getElementById("gameover").style.display = "none";
    document.getElementById("fin").style.display = "none";
    
    
    chicken=await alien1_menu(chicken,scene);
    duck=await alien2_menu(duck,scene);
    owl = await alien3_menu(owl,scene);
    model=true;
    await Promise.all([chicken, duck, owl,await loadMystery()]);

    loop(loopOn);*/
    //lancer premier niveau
    /*
    chicken=await alien1(chicken,scene);
    duck=await alien2(duck,scene);
    owl = await alien3(owl,scene);
    barrier= barriers(barrier,scene);
   // await initAsync();
    //addInstancedMesh();
    //tir_alien();
    model = true;
    await Promise.all([chicken, duck, owl, barrier,initAsync()]);
    loop(loopOn);*/
   // console.log("ccccccccc");
}

main();





let movingLeft = false;

/*
window.addEventListener("keydown", (event) => {
  switch (event.code) {
    case "KeyA":
      movingLeft = true;
      break;
  }
});*/
/*
window.addEventListener("keyup", (event) => {
  switch (event.code) {
    case "KeyA":
      movingLeft = false;
      break;
  }
});*/


function fin_level(){
  level++;
  for(let i=0;i<chicken.length;i++){
       
    scene.remove(chicken[i][3]);

  

}

for(let i=0;i<duck.length;i++){

  scene.remove(duck[i][3]);

}

for(let i=0;i<owl.length;i++){
  scene.remove(owl[i][3]);
}

for(let i=0;i<projectil_alien.length;i++){
  scene.remove(projectil_alien[i][0]);
}

for(let i=0;i<barrier.length;i++){
  scene.remove(barrier[i]);
}


chicken.splice(0, chicken.length);
duck.splice(0, duck.length);
owl.splice(0, owl.length);
barrier.splice(0,barrier.length);

dead_alien=0;

fin = true;
scene.remove(scene.getObjectByName("mystery"));

scene.remove(character_model);

}


setInterval(function() {
  
  if (model) {
    console.log("eheh");
    //if (!fin)tir_alien();
  
  }
}, 3000);

setInterval(() => {
  if (movingLeft) {
    if (character_model.position.x>=-13) character_model.position.x -= 0.3;
   // projectil_model.position.x -= 0.1;
   //if (cam_player) camera.lookAt(character_model.position);
   if (cam_player){
    camera.position.set(character_model.position.x, 2, 42);
  camera.lookAt(character_model.position);

  }
    render();
  }
}, 16);

let movingRight = false;

window.addEventListener("keydown", async (event) => {
  switch (event.code) {
    case "KeyK":

     fin_level();
     // level++;
      document.getElementById("left").innerHTML = '<strong>Level </strong> ' + level + '<br>';

      new_level();
      

      //render();
      break;

      case "KeyI":
        touch_i=!touch_i;
        break;

    case "KeyD":
      movingRight = true;
      break;

      case "KeyA":
        movingLeft = true;
        break;

        case "KeyM":
          
    if (audio.isPlaying) {
      audio.stop(); // arrête la lecture
    }
    else audio.play();
          break;

          case "Digit2":
            console.log("cameeeeera");
            cam_player = false;
            camera_lateral();
         
          break;

        case "Digit1":
       cam_player = true;
       camera.position.set(character_model.position.x, 2, 42);

       // Faire en sorte que la caméra regarde le personnage
       camera.lookAt(character_model.position);
     break;

     case "Digit0":
      console.log("cameeeeera");
      cam_player = false;
      camera_plateau();
   
    break;



        case "Space":
          
         

          if (AddProjectil){

          projectil_model2 = clone(projectil_model);


          projectil_model2.position.x=character_model.position.x;
   

          projectils.push(projectil_model2);

          scene.add(projectil_model2);

          
          tir=true;
          AddProjectil= false;

          
          

           // Cancel any existing timers
        for (var i = 0; i < projectileTimers.length; i++) {
          clearTimeout(projectileTimers[i]);
      }
    

      // Set a timer for this projectile
      var projectileTimer = setTimeout(function() {
          AddProjectil = true;
      }, 2000);

      // Record the timer for this projectile
      projectileTimers.push(projectileTimer);

          setTimeout(function() {
           // scene.add(projectil_model);
            AddProjectil = true;
          }, 1000); // délai de 3 secondes (en millisecondes
        }
        audio_arc.play();

        setTimeout(function() {
          audio_arc.stop();
        }, 500);
      
         
          break;
      
  }
  
});

window.addEventListener("keyup", (event) => {
  switch (event.code) {
    case "KeyD":
      
      movingRight = false;
      
      break;
      

      case "KeyA":
       
        movingLeft = false;
        
        break;
  }
});

setInterval(() => {
  if (movingRight) {

    if (character_model.position.x<=13)character_model.position.x += 0.3;
    //camera.position.set(character_model.position.x, 2, 42);

    // Faire en sorte que la caméra regarde le personnage
    if (cam_player){
      camera.position.set(character_model.position.x, 2, 42);
    camera.lookAt(character_model.position);

    }
   // camera.rotation.y = 0.1;
     // camera.rotation.set(-PI / 6, 0, 0); 
   /* camera.rotation.x -= Math.PI / 6; // Inclinaison vers le haut
camera.rotation.y += Math.PI; // Rotation de 180 degrés*/
    //projectil_model.position.x += 0.1;
    render();
  }
}, 16);