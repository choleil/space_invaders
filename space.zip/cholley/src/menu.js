import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader';

import { animation_base2 } from './animations'
import { animation_base3 } from './animations'
import { animation_base4 } from './animations'

import { scaleModel } from './scale'



const PI =Math.PI;

let chicken2=[];

const dracoLoader = new DRACOLoader();
dracoLoader.setDecoderPath( 'node_modules/three/examples/js/libs/draco/');// Spécifier le chemin vers le décodeur Draco

// Créer un chargeur GLTFLoader et lui ajouter le DracoLoader
const gltfLoader = new GLTFLoader();
gltfLoader.setDRACOLoader(dracoLoader);


async function alien1_menu(chicken,scene) {
    gltfLoader.load( 'http://localhost:5173/assets/models/lowpoly_duck_animated/output_model.glb', function ( gltf ) {
        const model = gltf.scene;
      
      
            chicken.push(["",true,0,model,gltf.animations]);
          

             scaleModel(chicken[0][3], chicken[0][3].scale.x*2.5);

             model.position.set(-6, 0, 10);
      
             model.rotation.y=PI;
             //chicken_model.rotation.y=PI;
            scene.add(chicken[0][3]);
            animation_base2(chicken);
            
      
      }, undefined, function ( error ) {
        console.error( error );
      });


    return chicken;
}


async function alien2_menu(duck,scene) {

    gltfLoader.load( 'http://localhost:5173/assets/models/low_poly_bird_animated/output_model.glb', function ( gltf ) {
    const model = gltf.scene;

    duck.push(["",true,0,model,gltf.animations]);

    model.position.set(-2, 0, 10);
    
    scaleModel(duck[0][3], duck[0][3].scale.x*0.25);
    scene.add(duck[0][3]);
    
    animation_base3(duck);
    
    
    }, undefined, function ( error ) {
    console.error( error );
    });
    return duck;
    }


    async function alien3_menu(owl,scene) {

        gltfLoader.load( 'http://localhost:5173/assets/models/lowpoly_animated_turkey/output_model.glb', function ( gltf ) {
    const model = gltf.scene;
    
    model.position.set(2.3,1,10);
    owl.push(["",true,0,model,gltf.animations]);
    scaleModel(owl[0][3], owl[0][3].scale.x*0.15);
    
    
    // owl_model.rotation.y=7*PI/6;
    scene.add(owl[0][3]);
    animation_base4(owl);
    
    
    
    
    }, undefined, function ( error ) {
    console.error( error );
    });
    return owl;
    
    }






export {alien1_menu,alien2_menu,alien3_menu}
